#ifndef TARGET_DETECTOR_H
#define TARGET_DETECTOR_H

#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <geometry_msgs/PoseStamped.h>
#include <std_msgs/Int32MultiArray.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/common/centroid.h>
#include <pcl_conversions/pcl_conversions.h>
#include <Eigen/Dense>
#include <tf2_ros/transform_listener.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <tf2_ros/transform_broadcaster.h>

class TargetDetector
{
public:
    TargetDetector(ros::NodeHandle &nh);

private:
    void pointCloudCallback(const sensor_msgs::PointCloud2ConstPtr &cloud_msg);
    void localPositionCallback(const geometry_msgs::PoseStampedConstPtr &msg);
    // void bboxCallback(const std_msgs::Int32MultiArrayConstPtr &bbox_msg);
    void computeAndPublishPose();

    ros::Subscriber cloud_sub_, local_position_sub_;
    ros::Subscriber bbox_sub_;
    ros::Publisher target_centroid_cam_pub_, target_centroid_map_pub_;

    sensor_msgs::PointCloud2ConstPtr latest_cloud_;
    std::vector<int> latest_bbox_; // {x1, y1, x2, y2}

    tf2_ros::Buffer tf_buffer_;              // saves all the transforms
    tf2_ros::TransformListener tf_listener_; // listens to the transforms, without this, the buffer will not be updated
    tf2_ros::TransformBroadcaster broadcaster_;
};

#endif // TARGET_DETECTOR_H
